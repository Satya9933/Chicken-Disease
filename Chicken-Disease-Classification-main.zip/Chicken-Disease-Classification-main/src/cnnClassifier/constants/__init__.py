from pathlib import Path


CONFIG_FILE_PATH = Path("config/config.yaml")
SECRETS_FILE_PATH = Path("secrets.yaml")
PARAMS_FILE_PATH = Path("params.yaml")
